import React from 'react';

const AimsScope = () => {
    return (
        <div>
            <h1>Aims & Scope</h1>
            <p>Content for Aims & Scope goes here.</p>
        </div>
    );
};

export default AimsScope;
