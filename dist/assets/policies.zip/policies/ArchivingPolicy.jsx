import React from 'react';

const ArchivingPolicy = () => {
    return (
        <div>
            <h1>Archiving Policy</h1>
            <p>Content for Archiving Policy goes here.</p>
        </div>
    );
};

export default ArchivingPolicy;
