import React from 'react';

const PlagiarismPolicy = () => {
    return (
        <div>
            <h1>Plagiarism Policy</h1>
            <p>Content for Plagiarism Policy goes here.</p>
        </div>
    );
};

export default PlagiarismPolicy;
