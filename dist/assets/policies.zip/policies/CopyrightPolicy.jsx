import React from 'react';

const CopyrightPolicy = () => {
    return (
        <div>
            <h1>Copyright Policy</h1>
            <p>Content for Copyright Policy goes here.</p>
        </div>
    );
};

export default CopyrightPolicy;
