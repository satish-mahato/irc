import React from 'react';

const AdvertisingPolicy = () => {
    return (
        <div>
            <h1>Advertising Policy</h1>
            <p>Content for Advertising Policy goes here.</p>
        </div>
    );
};

export default AdvertisingPolicy;
