import React from 'react';

const DataSharingPolicy = () => {
    return (
        <div>
            <h1>DataSharing Policy</h1>
            <p>Content for DataSharing Policy goes here.</p>
        </div>
    );
};

export default DataSharingPolicy;
