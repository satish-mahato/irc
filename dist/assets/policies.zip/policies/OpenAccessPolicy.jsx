import React from 'react';

const OpenAccessPolicy = () => {
    return (
        <div>
            <h1>OpenAccess Policy</h1>
            <p>Content for OpenAccess Policy goes here.</p>
        </div>
    );
};

export default OpenAccessPolicy;
