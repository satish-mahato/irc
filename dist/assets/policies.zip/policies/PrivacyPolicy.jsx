import React from 'react';

const PrivacyPolicy = () => {
    return (
        <div>
            <h1>Privacy Policy</h1>
            <p>Content for Privacy Policy goes here.</p>
        </div>
    );
};

export default PrivacyPolicy;
